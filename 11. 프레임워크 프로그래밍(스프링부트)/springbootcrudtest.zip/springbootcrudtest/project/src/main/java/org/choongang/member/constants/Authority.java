package org.choongang.member.constants;

public enum Authority {
    USER,
    ADMIN
}