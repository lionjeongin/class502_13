package coffee;

public class Menu {
    public static final int StarAmericano= 4000;
    public static final int StarLatte = 4300;

    public static final int BeanAmericano = 4100;
    public static final int BeanLatte = 4500;
}
